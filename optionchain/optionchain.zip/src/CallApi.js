import axios from 'axios';
import * as Models from './models/OptionChain';

export const callApi = async (lastTimeStamp, expiryDate, symbol) => {
    try {
        let data = JSON.stringify({
            "size": 20,
            "query": {
                "bool": {
                    "must": [
                        { "match": { "symbol": symbol }},
                        { "match": { "expiry": expiryDate }},
                        { "range": {
                            "timeStamp": {
                                "gt": lastTimeStamp
                            }
                        }}
                    ]
                }
            },
            "sort": [
                {
                    "timeStamp": {
                        "order": "asc"
                    }
                }
            ]
        });
        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'http://localhost:9200/optionchain/_search?pretty',
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };
        const response = await axios.request(config);

        if (response.data.hits.total.value > 0) {
            console.log('Elasticsearch returned results:', response.data.hits.hits);

            var restObj = mapFromJsonToClass(response.data);
            return {
                data: restObj.hits.hits.map(hit => hit._source),
                lastTimeStamp: getLastTimeStamp(response)
            };
        } else {
            console.log('No results found');
            return { data: [], lastTimeStamp };
        }
    } catch (err) {
        throw new Error(err.message);
    }
};

function mapFromJsonToClass(jsonData) {
    const hitData = jsonData.hits.hits.map(hit =>
        new Models.Hit(
            hit._index,
            hit._id,
            hit._score,
            new Models.Source(
                hit._source.symbol,
                hit._source.ltp,
                hit._source.ltp_Chg,
                hit._source.timeStamp,
                hit._source.expiry,
                hit._source.optionChain.map(item =>
                    new Models.OptionChain(
                        item.call_Volume, item.call_OIChg, item.call_OI, item.call_LTP, item.Strike,
                        item.put_LTP, item.put_OI, item.put_OIChg, item.put_Volume, item.call_LTPChg, item.put_LTPChg,
                        item.PCR, item.OIDiff, item.OIDiff_Chg
                    )
                )
            )
        )
    );

    const hitsData = new Models.Hits(
        new Models.Total(jsonData.hits.total.value, jsonData.hits.total.relation),
        jsonData.hits.max_score,
        hitData
    );

    const shardsData = new Models.Shards(
        jsonData._shards.total,
        jsonData._shards.successful,
        jsonData._shards.skipped,
        jsonData._shards.failed
    );

    const jsonResponse = new Models.JsonResponse(
        jsonData.took,
        jsonData.timed_out,
        shardsData,
        hitsData
    );
    return jsonResponse;
}

function getLastTimeStamp(response) {
    const hits = response.data.hits.hits;
    const lastItem = hits[hits.length - 1];
    const lastTimeStamp = lastItem._source.timeStamp;
    return lastTimeStamp;
}