import React, { useState, useEffect, useRef } from 'react';
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';
import {startFetchingOptionsChain} from './OptionsChartGetter';
import Query from './Query';
import './styles/App.css';
Highcharts.AST.bypassHTMLFiltering = true;

const INDEX = 'INDEX';
function App()
{
  const [data, setData] = useState([]);
  const [lastTimeStamp, setLastTimeStamp] = useState(getTimeString('2024-01-01'));
  const [expiryDate, setExpiryDate] = useState(getTimeString('2024-09-18'));
  const [symbol, setSymbol] = useState('BANKNIFTY');
  const [error, setError] = useState(null);
  const lastTimeStampRef = useRef(lastTimeStamp);
  const expiryDateRef = useRef(expiryDate);
  const symbolRef = useRef(symbol);
  const hasStartedFetching = useRef(false);
  const chartRef = useRef(null);

  symbolRef.current = symbol;
  lastTimeStampRef.current = lastTimeStamp;
  expiryDateRef.current = expiryDate;

  useEffect(() => {
    if (!hasStartedFetching.current) {
      startFetchingOptionsChain(lastTimeStampRef, expiryDateRef, symbolRef, setData, setLastTimeStamp, setError);
      hasStartedFetching.current = true;
    }
  }, [lastTimeStamp]);

  
  useEffect(() => {

    if (data.length === 0) {
      if (chartRef.current) {
        while (chartRef.current.series.length > 0) {
          chartRef.current.series[0].remove(false);
        }
        chartRef.current.redraw();
      }
      return;
    }
    
    var optionsSeriesArr = MapToSeriesStirikeWise(data);
    if(optionsSeriesArr && optionsSeriesArr.length > 0)
    {
      var seriesArray = optionsSeriesArr;
      if (chartRef.current) {
        seriesArray.forEach((series, index) => {
          if (chartRef.current.series[index]) {
            chartRef.current.series[index].setData(series.data, false);
          } else {
            chartRef.current.addSeries(series, false);
          }
        });
        chartRef.current.redraw();
      } else {
        var seriesCount = seriesArray.length;
        const strikes = Array.from({ length: seriesCount }, (_, i) => i);
        const axes = strikes.map((item, index) => ({
          top: ((index / seriesCount) * 100) + "%",
          height: (100 / seriesCount) + "%",
          offset: 50,
        }));
        const chart = Highcharts.stockChart('container', {
          chart: {
            events: {
              load: function() {
                var chart = this,
                  series = this.series[3],
                  xAxis = chart.xAxis[0],
                  newStart = series.xData[series.xData.length-15],
                  newEnd = series.xData[series.xData.length-5];
                  xAxis.setExtremes(newStart, newEnd);
              }
            },
            navigator: {
              enabled: true,
            },
            rangeSelector: {
              selected: 1,
            },
            type: 'line',
            zoomType: 'x',
            //panning: true,
            //panKey: 'shift',
            height: 1200,
            styledMode: true,
          },
          boost: {
            useGPUTranslations: true,
          },
          title: {
            text: 'Option Chain',
          },
          subtitle: {
            text: 'BankNifty',
          },
          tooltip: {
            pointFormat: '<span style="color:{series.color}">' +
                    '{point.y}</span>',
                valueDecimals: 2,
                split: true
          },
          series: seriesArray,
          //yAxis: axes,
          plotOptions: {  
          line: {
            dataLabels: {
              enabled: true,
            },
            enableMouseTracking: true,
          },
            series: {
              dataLabels: [
                {
                  //align: 'left',
                  //className : 'highlight',
                  //format: 'CALL:{point.call_OIChg}|PUT:{point.put_OIChg}',
                  padding: 0,
                  allowOverlap: true,
                  enabled: true,
                  useHTML: true,
                  formatter: function() {
                    let html = '';
                    if(this.series.name !== 'INDEX')
                    {
                      html = `<table class='points-data' cellpadding="0" cellspacing="0" border="0">
                      <tr>
                      <td class="call">${GetStyleFor(this.point.data.OIDiff, 'OIDiff')}</td>
                      <td>|</td>
                      <td class="put">${GetStyleFor(this.point.data.OIDiff_Chg, 'OIDiff_Chg')}</td>
                      </tr>
                      <tr>
                      <td class="call">${GetStyleFor(this.point.data.call_OIChg, 'call_OIChg')}</td>
                      <td>|</td>
                      <td class="put">${GetStyleFor(this.point.data.put_OIChg, 'put_OIChg')}</td>
                      </tr>
                      <tr>
                      <td class="call">${GetStyleFor(this.point.data.call_OI, 'call_OI')}</td>
                      <td>|</td>
                      <td class="put">${GetStyleFor(this.point.data.put_OI, 'put_OI')}</td>
                      </tr>
                              </table>`;
                    }
                    else
                    {//total_OIDiff, total_OIDiff_Chg, ltp_Chg
                      html = `<div style="margin-left: 160%;">${GetStyleFor(this.point.data.total_OIDiff, 'total_OIDiff')} 
                      <br/>${GetStyleFor(this.point.data.total_OIDiff_Chg, 'total_OIDiff_Chg')}
                      <br/>${GetStyleFor(this.point.data.ltp_Chg, 'ltp_Chg')}</div>`;
                    }
                    return html;
                  },      
                }
              ],
              marker: {
                enabled: true,
                states: {
                  hover: {
                    enabled: true,
                  },
                },
              },
              states: {
                hover: {
                  lineWidthPlus: 0,
                },
                inactive: {
                  opacity: 1,
                },
              },
            },
          },
        });
        chartRef.current = chart;
      }
    }
  }, [data]);

  return (
    <div>
      <Query
        setSymbol={setSymbol}
        setExpiryDate={setExpiryDate}
        setLastTimeStamp={setLastTimeStamp}
        setData={setData}
        lastTimeStampRef={lastTimeStampRef}
      />
      <div id="container"></div>
    </div>
  );
}

function GetStyleFor(value, context)
{
    let size = '';
    let html = `${value}`;
    switch(context)
    {
        case 'call_OIChg':
        case 'put_OIChg':
          size = GetFontSize(value,15) + 'px';
          html = `<span class="value" style="font-size: ${size};" data-value="${value}">${value}</span>`;
          break;
      case 'OIDiff':
      case 'OIDiff_Chg':
          size = GetFontSize(value,3)+ 'px';
          html = `<span class="value" style="font-size: ${size};" data-value="${value}">${value}</span>`;
          break;
      case 'call_OI':
      case 'put_OI':
          size = GetFontSize(value,1.5) + 'px';
          html = `<span class="value" style="font-size: ${size};" data-value="${value}">${value}</span>`;
          break;
      case 'total_OIDiff':
      case 'total_OIDiff_Chg':
      case 'ltp_Chg':
            size = GetFontSize(value,0.5) + 'px';
            html = `<span class="value" style="font-size: ${size};" data-value="${value}">${value}</span>`;
            break;
    }
    return html;
}

function GetFontSize(value, factor = 1, minFontSize = 9, maxFontSize = 15)
{
    let fontSize = Math.abs(value * factor);
    if (minFontSize > fontSize)
        fontSize = minFontSize;
    else if(fontSize > maxFontSize)
        fontSize = maxFontSize;
    return fontSize;
}

function MapToSeriesStirikeWise(opyionChainsList)
{
    opyionChainsList = opyionChainsList.map(optionData => ({
      ...optionData,
      nearestStrikes: findNearestStrikes(optionData.ltp, optionData.optionChain, 3)
    }));
    
    // Step 2: Create a map to store series data based on "strike"
    var seriesMap = new Map();
    // Step 3: Iterate through the JSON data and populate the map
    //var i = 0;
    opyionChainsList.forEach(entry => {
      if(!entry || !entry.nearestStrikes || entry.nearestStrikes.length < 0)
        return;

        let total_OIDiff = 0, total_OIDiff_Chg = 0, index_LTPChg = 0;
        entry.nearestStrikes.forEach(option => {
            const strike = option.strike;
            if (!seriesMap.has(strike)) {
                seriesMap.set(strike, {
                    name: `Strike ${strike}`,
                    //yAxis: i++,
                    data: []
                });
            }
            
            seriesMap.get(strike).data.push({
                x: new Date(entry.timeStamp).getTime(),
                y: strike, // or any other value you want to plot
                data: option
            });
            total_OIDiff += option.OIDiff;
            total_OIDiff_Chg += option.OIDiff_Chg;
        });

        if (!seriesMap.has(INDEX)) {
          seriesMap.set(INDEX, {
              name: `${INDEX}`,
              //yAxis: i++,
              data: []
          });
        }
        total_OIDiff = DecimaltoOriginalValue(total_OIDiff);
        total_OIDiff_Chg = DecimaltoOriginalValue(total_OIDiff_Chg);
        seriesMap.get(INDEX).data.push({
            x: new Date(entry.timeStamp).getTime(),
            y: entry.ltp, // or any other value you want to plot
            data: {total_OIDiff, total_OIDiff_Chg, ltp_Chg : entry.ltp_Chg}
        });
    });

    //Reorder the series
    //seriesMap = new Map([...seriesMap.entries()].sort((a, b) => b[0] - a[0]));//Sort by descending order
    //let l = 0; 
    //seriesMap.forEach((k)=>{k.yAxis = l++;})
    
    // Step 4: Convert the map to an array of series objects
    const seriesArray = Array.from(seriesMap.values());

    // Step 5: Sort the series array based on "strike"
    seriesArray.sort((a, b) => {
        const strikeA = parseInt(a.name.split(' ')[1], 10);
        const strikeB = parseInt(b.name.split(' ')[1], 10);
        return strikeA - strikeB;
    });
    return seriesArray;
}

const findNearestStrikes = (ltp, optionChain, count) => {
  if(!optionChain || optionChain.length <=0)
    return;
  const sortedOptionChain = optionChain;//.sort((a, b) => a.strike - b.strike);
  const nearestIndex = sortedOptionChain
    .map((entry, index) => ({ strike: entry.strike, index }))
    .sort((a, b) => Math.abs(a.strike - ltp) - Math.abs(b.strike - ltp))[0]
    .index;

  const startIndex = Math.max(0, nearestIndex - count);
  const endIndex = Math.min(sortedOptionChain.length - 1, nearestIndex + count);

  return sortedOptionChain
    .slice(startIndex, endIndex + 1)
    .map(entry => entry);
};

function getTimeString(dateValue)
{
  let d = new Date(dateValue + 'T00:00:00.000+05:30');
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString();
}

function DecimaltoOriginalValue(val) {
  let finalVal = 0;
  try{
    finalVal = isNaN(val) ? val : parseFloat(val.toFixed(2));
  }
  catch(e)
  {
      debugger;
      console.log(e);
  }
  return finalVal;
}
export default App;