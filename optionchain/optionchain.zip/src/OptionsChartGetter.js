import { callApi } from './CallApi';

export const fetchOptionsChainRealTime = async (lastTimeStamp, expiryDate, symbol, setData, setLastTimeStamp, setError) => {
    try {
        const result = await callApi(lastTimeStamp, expiryDate, symbol);
        if(result.data && result.data.length > 0)
        {
            setData(prevData => [...prevData, ...result.data]);
            setLastTimeStamp(result.lastTimeStamp);
        }
    } catch (err) {
        setError(err);
    }
};

export const startFetchingOptionsChain = (lastTimeStampRef, expiryDateRef, symbolRef, setData, setLastTimeStamp, setError) => {
    const fetchData = async () => {
        const startTime = Date.now();
        await fetchOptionsChainRealTime(lastTimeStampRef.current, expiryDateRef.current, symbolRef.current, setData, setLastTimeStamp, setError);
        const endTime = Date.now();
        const elapsedTime = endTime - startTime;
        const delay = Math.max(3000 - elapsedTime, 0); // Change interval to 3 seconds (3000 ms)
        setTimeout(fetchData, delay);
    };

    fetchData();
};