class Shards {
    constructor(total, successful, skipped, failed) {
        this.total = total;
        this.successful = successful;
        this.skipped = skipped;
        this.failed = failed;
    }
}

class Total {
    constructor(value, relation) {
        this.value = value;
        this.relation = relation;
    }
}

class OptionChain {
    constructor(call_Volume, call_OIChg, call_OI, call_LTP, Strike, put_LTP, put_OI, put_OIChg, put_Volume, call_LTPChg, put_LTPChg, PCR, OIDiff, OIDiff_Chg) {
        this.call_Volume = DecimaltoOriginalValue(call_Volume);
        this.call_OIChg = DecimaltoOriginalValue(call_OIChg);
        this.call_OI = DecimaltoOriginalValue(call_OI);
        this.call_LTP = DecimaltoOriginalValue(call_LTP);
        this.call_LTPChg = DecimaltoOriginalValue(call_LTPChg);
        this.strike = Strike;
        this.put_LTP = DecimaltoOriginalValue(put_LTP);
        this.put_LTPChg = DecimaltoOriginalValue(put_LTPChg);
        this.put_OI = DecimaltoOriginalValue(put_OI);
        this.put_OIChg = DecimaltoOriginalValue(put_OIChg);
        this.put_Volume = DecimaltoOriginalValue(put_Volume);
        this.PCR =DecimaltoOriginalValue(PCR);
        this.OIDiff = DecimaltoOriginalValue(OIDiff);
        this.OIDiff_Chg = DecimaltoOriginalValue(OIDiff_Chg);
    }
}

class Source {
    constructor(symbol, ltp, ltp_Chg, timeStamp, expiry, optionChain) {
        this.symbol = symbol;
        this.ltp = ltp;
        this.ltp_Chg = ltp_Chg
        this.timeStamp = timeStamp;
        this.expiry = expiry;
        this.optionChain = optionChain;
    }
}

class Hit {
    constructor(_index, _id, _score, _source) {
        this._index = _index;
        this._id = _id;
        this._score = _score;
        this._source = _source;
    }
}

class Hits {
    constructor(total, max_score, hits) {
        this.total = total;
        this.max_score = max_score;
        this.hits = hits;
    }
}

class JsonResponse {
    constructor(took, timed_out, _shards, hits) {
        this.took = took;
        this.timed_out = timed_out;
        this._shards = _shards;
        this.hits = hits;
    }
}

function DecimaltoOriginalValue(val) {
    let finalVal = 0;
    try{
        if (typeof val === 'string') {
			let parsed = parseFloat(val);
			if (!isNaN(parsed)) {
				finalVal = parseFloat(parsed.toFixed(2));
			}
		}
        else
        {
	        finalVal = isNaN(val) ? val : parseFloat(val.toFixed(2));
        }
    }
    catch(e)
    {
        debugger;
        console.log(e);
    }
    return finalVal;
}

export { Shards, Total, OptionChain, Source, Hit, Hits, JsonResponse };
/*
// JSON response string
const jsonResponseString = `{
    "took": 125,
    "timed_out": false,
    "_shards": {
        "total": 1,
        "successful": 1,
        "skipped": 0,c
        "failed": 0
    },
    "hits": {
        "total": {
            "value": 54,
            "relation": "eq"
        },
        "max_score": 1.0,
        "hits": [
            {
                "_index": "optionchain",
                "_id": "s1ufxpEBjR2_pzK7wizt",
                "_score": 1.0,
                "_source": {
                    "symbol": "BANKNIFTY",
                    "ltp": 50599.66,
                    "timeStamp": "2024-09-06T14:47:24.539Z",
                    "expiry": "2024-09-11T00:00:00.000Z",
                    "optionChain": [
                        {
                            "p0_Volume": 0.05,
                            "p1_OIChg": 0.01,
                            "p2_OIlakhCallOI": 0.01,
                            "p3_LTP": 1061.16,
                            "p4_Strike": 49600,
                            "p5_LTP": 113.11,
                            "p6_OIlakhPutOI": 3.71,
                            "p7_OIChg": 0.41,
                            "p8_Volume": 84.01
                        },
                        {
                            "p0_Volume": 0.05,
                            "p1_OIChg": 0.01,
                            "p2_OIlakhCallOI": 0.01,
                            "p3_LTP": 1061.16,
                            "p4_Strike": 49600,
                            "p5_LTP": 113.11,
                            "p6_OIlakhPutOI": 3.71,
                            "p7_OIChg": 0.41,
                            "p8_Volume": 84.01
                        }
                    ]
                }
            }
        ]
    }
}`;

// Deserialize JSON response
const jsonResponse = JSON.parse(jsonResponseString);

// Accessing properties
console.log(jsonResponse.took); // 125
console.log(jsonResponse.timed_out); // false
console.log(jsonResponse._shards.total); // 1
console.log(jsonResponse.hits.total.value); // 54
console.log(jsonResponse.hits.hits[0]._source.symbol); // "BANKNIFTY"
console.log(jsonResponse.hits.hits[0]._source.optionChain[0].p0_Volume); // 0.05
*/