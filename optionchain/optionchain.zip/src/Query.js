import React, { useState } from 'react';
import './styles/Query.css';

function Query({ setSymbol, setExpiryDate, setLastTimeStamp, setData, lastTimeStampRef }) {
  const [symbolInput, setSymbolInput] = useState('BANKNIFTY');
  const [expiryDateInput, setExpiryDateInput] = useState(getTimeString('2024-09-18'));;
  const [startDateInput, setStartDateInput] = useState(getTimeString('2024-01-01'));
  
  const handleSubmit = () => {
    setData([]);
    setSymbol(symbolInput);
    setExpiryDate(getTimeString(expiryDateInput));
    setLastTimeStamp(getTimeString(startDateInput));
  };

  return (
    <div className="query-container">
    <div className="query-item">
        <label htmlFor="symbolInput" className="query-label">Symbol</label>
        <input
        id="symbolInput"
        type="text"
        placeholder="Symbol"
        value={symbolInput}
        onChange={(e) => setSymbolInput(e.target.value)}
        className="query-input"
        />
    </div>
    <div className="query-item">
        <label htmlFor="expiryDateInput" className="query-label">Expiry Date</label>
        <input
        id="expiryDateInput"
        type="text"
        placeholder="Expiry Date"
        value={expiryDateInput}
        onChange={(e) => setExpiryDateInput(e.target.value)}
        className="query-input"
        />
    </div>
    <div className="query-item">
        <label htmlFor="startDateInput" className="query-label">Data From Date</label>
        <input
        id="startDateInput"
        type="text"
        placeholder="Data From Date"
        value={startDateInput}
        onChange={(e) => setStartDateInput(e.target.value)}
        className="query-input"
        />
    </div>
    <button onClick={handleSubmit} className="query-button">Submit</button>
    <label className="query-label">Last Time Stamp: {lastTimeStampRef.current}</label>
    </div>
  );
}

function getTimeString(dateValue)
{
  let date = new Date(dateValue);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
  const day = String(date.getDate()).padStart(2, '0');
  let d = new Date(`${year}-${month}-${day}` + 'T00:00:00.000+05:30');
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString();
}

export default Query;